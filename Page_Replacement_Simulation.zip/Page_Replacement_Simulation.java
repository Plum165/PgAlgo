import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
// Main class for the page replacement simulation
public class Page_Replacement_Simulation {

    // FIFO Page Replacement Algorithm
    private static int firstInFirstOut(final Memory frames, final Integer[] pageReferences) {
        System.out.println("First-in First-out (FIFO)");
        int pageFaults = 0;
        int frame = 0; // Pointer to track the frame to replace next

        for (int ref : pageReferences) {
            // Check if the page is already in memory
            if (!(frames.contains(ref))) {
                if (frames.isEmpty(frame)) {
                    // Place page if the frame is empty
                    frames.put(frame, ref);
                } else {
                    // Replace the oldest page
                    int currentPage = frames.get(frame);
                    frames.replace(currentPage, ref);
                }
                pageFaults++;
                frame = (frame + 1) % frames.size(); // Circular replacement
                System.out.println(ref + ": " + frames);
            } else {
                System.out.println(ref + ": " + "-"); // No page fault
            }
        }
        return pageFaults;
    }

    // Optimal Page Replacement Algorithm
    private static int optimalPageReplacement(final Memory frames, final Integer[] pageReferences) {
        System.out.println("Optimal Page Replacement (OPT)");
        int pageFaults = 0;

        for (int i = 0; i < pageReferences.length; i++) {
            int page = pageReferences[i];

            if (frames.contains(page)) {
                System.out.println(page + ": " + "-");
                continue; // Page already in memory
            }

            pageFaults++;

            boolean placed = false;
            for (int f = 0; f < frames.size(); f++) {
                if (frames.isEmpty(f)) {
                    frames.put(f, page);
                    placed = true;
                    System.out.println(page + ": " + frames);
                    break;
                }
            }
            if (placed) continue;

            // Replace the page that will be used farthest in the future
            int frameToReplace = -1;
            int farthestUse = -1;

            for (int f = 0; f < frames.size(); f++) {
                int currentPage = frames.get(f);
                int nextUse = Integer.MAX_VALUE;
                for (int j = i + 1; j < pageReferences.length; j++) {
                    if (pageReferences[j] == currentPage) {
                        nextUse = j;
                        break;
                    }
                }
                if (nextUse > farthestUse) {
                    farthestUse = nextUse;
                    frameToReplace = f;
                }
            }

            frames.put(frameToReplace, page);
            System.out.println(page + ": " + frames);
        }

        return pageFaults;
    }

    // Least Recently Used (LRU) Page Replacement
    private static int leastRecentlyUsed(final Memory frames, final Integer[] pageReferences) {
        System.out.println("Least Recently Used (LRU)");
        int pageFaults = 0;
        List<Integer> recentHistory = new ArrayList<>(); // Tracks usage order

        for (int page : pageReferences) {
            if (frames.contains(page)) {
                // Move page to the end (most recently used)
                recentHistory.remove((Integer) page);
                recentHistory.add(page);
                System.out.println(page + ": " + "-");
                continue;
            }

            pageFaults++;

            boolean placed = false;
            for (int f = 0; f < frames.size(); f++) {
                if (frames.isEmpty(f)) {
                    frames.put(f, page);
                    recentHistory.add(page);
                    placed = true;
                    System.out.println(page + ": " + frames);
                    break;
                }
            }
            if (placed) continue;

            // Replace least recently used page
            int lruPage = recentHistory.get(0);
            int lruIndex = frames.indexOf(lruPage);
            frames.put(lruIndex, page);

            recentHistory.remove(0);
            recentHistory.add(page);
            System.out.println(page + ": " + frames);
        }

        return pageFaults;
    }

    // Clock Second-Chance Algorithm
    private static int clockSecondChance(final Memory frames, final Integer[] pageReferences) {
        System.out.println("Clock Second Chance");
        int pageFaults = 0;
        int clockHand = 0; // Pointer for clock rotation
        Integer[] ref = new Integer[frames.size()]; // Reference bits

        for (int i = 0; i < frames.size(); i++) ref[i] = 0;

        for (int page : pageReferences) {
            if (frames.contains(page)) {
                ref[frames.indexOf(page)] = 1;
                System.out.println(page + ": " + frames + "\tRef Bits: " + print(ref));
                continue;
            }

            pageFaults++;

            while (true) {
                if (frames.isEmpty(clockHand)) {
                    frames.put(clockHand, page);
                    ref[frames.indexOf(page)] = 1;
                    clockHand = (clockHand + 1) % frames.size();
                    break;
                } else if (ref[clockHand] == 0) {
                    ref[clockHand] = 1;
                    frames.put(clockHand, page);
                    clockHand = (clockHand + 1) % frames.size();
                    break;
                } else {
                    ref[clockHand] = 0;
                    clockHand = (clockHand + 1) % frames.size();
                }
            }
            System.out.println(page + ": " + frames + "\tRef Bits: " + print(ref));
        }

        return pageFaults;
    }

    // Clock with Dirty Bit Algorithm
    private static int clockDirtyBit(final Memory frames, final Integer[] pageReferences) {
        System.out.println("Clock Dirty Bit");
        int pageFaults = 0;
        int clockHand = 0;
        Integer[] ref = new Integer[frames.size()];
        Integer[] dirt = new Integer[frames.size()]; // Dirty bits

        for (int i = 0; i < frames.size(); i++) {
            ref[i] = 0;
            dirt[i] = 0;
        }

        for (int i = 0; i < pageReferences.length; i++) {
            int page = pageReferences[i];
            boolean isWrite = (i % 3 == 0); // Simulate write every 3rd access

            if (frames.contains(page)) {
                int index = frames.indexOf(page);
                ref[index] = 1;
                if (isWrite) dirt[index] = 1;
                System.out.println(page + ": " + frames + "\tRef Bits: " + print(ref) + " |Dirt Bits: " + print(dirt));
                continue;
            }

            pageFaults++;

            while (true) {
                if (frames.isEmpty(clockHand)) {
                    frames.put(clockHand, page);
                    ref[clockHand] = 1;
                    dirt[clockHand] = isWrite ? 1 : 0;
                    clockHand = (clockHand + 1) % frames.size();
                    break;
                }

                if (ref[clockHand] == 0 && dirt[clockHand] == 0) {
                    frames.put(clockHand, page);
                    ref[clockHand] = 1;
                    dirt[clockHand] = isWrite ? 1 : 0;
                    clockHand = (clockHand + 1) % frames.size();
                    break;
                } else {
                    if (ref[clockHand] == 1) ref[clockHand] = 0;
                    else if (dirt[clockHand] == 1) dirt[clockHand] = 0;
                    clockHand = (clockHand + 1) % frames.size();
                }
            }
            System.out.println(page + ": " + frames + "\tRef Bits: " + print(ref) + " |Dirt Bits: " + print(dirt));
        }

        return pageFaults;
    }

    // Clock with N Chances Algorithm
    private static int clockNChances(final Memory frames, final Integer[] pageReferences, final int chance) {
        System.out.println("Clock " + chance + " Chances");
        int pageFaults = 0;
        int clockHand = 0;
        Integer[] ref = new Integer[frames.size()];

        for (int i = 0; i < frames.size(); i++) ref[i] = 0;

        for (int page : pageReferences) {
            if (frames.contains(page)) {
                ref[frames.indexOf(page)] = chance;
                System.out.println(page + ": " + frames + "\tRef Bits: " + print(ref));
                continue;
            }

            pageFaults++;

            while (true) {
                if (frames.isEmpty(clockHand)) {
                    frames.put(clockHand, page);
                    ref[clockHand] = chance;
                    clockHand = (clockHand + 1) % frames.size();
                    break;
                } else if (ref[clockHand] == 0) {
                    ref[clockHand] = chance;
                    frames.put(clockHand, page);
                    clockHand = (clockHand + 1) % frames.size();
                    break;
                } else {
                    ref[clockHand]--;
                    clockHand = (clockHand + 1) % frames.size();
                }
            }
            System.out.println(page + ": " + frames + "\tRef Bits: " + print(ref));
        }

        return pageFaults;
    }

    // Helper to print arrays (e.g., ref or dirt bits)
    public static String print(Integer[] arr) {
        String s = "[ ";
        for (int i : arr) s = s + i + " ";
        s += "]";
        return s;
    }

    // Menu display
    private static void menu() {
        System.out.println("Please choose an option by entering the corresponding number:");
        System.out.println("1. First-In First-Out (FIFO)           - Replace the oldest loaded page.");
        System.out.println("2. Least Recently Used (LRU)          - Replace the page that was used least recently.");
        System.out.println("3. Optimal (OPT)                      - Replace the page that will not be used for the longest time.");
        System.out.println("4. Second-Chance Clock                - FIFO with a reference bit to give a second chance.");
        System.out.println("5. Dirty Bit Clock                    - Prefer replacing unmodified (clean) pages.");
        System.out.println("6. N-Chance Clock                     - Pages get up to N chances based on usage before replacement.");
        System.out.println("7. Run All Algorithms                 - Execute and compare all algorithms.");
        System.out.println("8. Set Number of Frames               - Change the memory frame size.");
        System.out.println("9. Set Reference String               - Change the reference string.");
        System.out.println("10. Exit                               - Quit the simulator.");
    }

    // Entry point
    public static void main(final String[] args) {
        final Scanner stdIn = new Scanner(System.in);
        boolean flag = false;
        System.out.println("Welcome to the Page Replacement Simulator!");
        System.out.println("Enter the physical memory size (number of frames):");
        int numFrames = stdIn.nextInt();
        stdIn.nextLine();

        System.out.println("Enter the string of page references:");
        Integer[] referenceString = toArray(stdIn.nextLine());

        while (true) {
            menu();
            String choice = stdIn.nextLine();

            switch (choice) {
                case "1":
                    System.out.printf("FIFO Page Faults: %d\n\n", firstInFirstOut(new Memory(numFrames), referenceString));
                    break;
                case "2":
                    System.out.printf("LRU Page Faults: %d\n\n", leastRecentlyUsed(new Memory(numFrames), referenceString));
                    break;
                case "3":
                    System.out.printf("OPT Page Faults: %d\n\n", optimalPageReplacement(new Memory(numFrames), referenceString));
                    break;
                case "4":
                    System.out.printf("Clock Second Chance\nPage faults: %d\n\n", clockSecondChance(new Memory(numFrames), referenceString));
                    break;
                case "5":
                    System.out.printf("Clock Dirt Chance\nPage faults: %d\n\n", clockDirtyBit(new Memory(numFrames), referenceString));
                    break;
                case "6":
                    System.out.println("How many chances should a page have?");
                    int n = stdIn.nextInt();
                    stdIn.nextLine();
                    System.out.printf("Clock N Chances\nPage faults: %d\n\n", clockNChances(new Memory(numFrames), referenceString, n));
                    break;
                case "7":
                    System.out.println("How many chances should a page have? ");
                    int c = stdIn.nextInt();
                    stdIn.nextLine();
                    System.out.printf("FIFO Page Faults: %d\n\n", firstInFirstOut(new Memory(numFrames), referenceString));
                    System.out.printf("LRU Page Faults: %d\n\n", leastRecentlyUsed(new Memory(numFrames), referenceString));
                    System.out.printf("OPT Page Faults: %d\n\n", optimalPageReplacement(new Memory(numFrames), referenceString));
                    System.out.printf("Page faults: %d\n\n", clockSecondChance(new Memory(numFrames), referenceString));
                    System.out.printf("Page faults: %d\n\n", clockDirtyBit(new Memory(numFrames), referenceString));
                    System.out.printf("Page faults: %d\n\n", clockNChances(new Memory(numFrames), referenceString, c));
                    break;
                case "8":
                    System.out.println("Enter the physical memory size (number of frames):");
                    numFrames = stdIn.nextInt();
                    stdIn.nextLine();
                    System.out.println("Change has been done");
                    break;
                case "9":
                    System.out.println("Enter the string of page references:");
                    referenceString = toArray(stdIn.nextLine());
                    System.out.println("Change has been done");
                    break;
                case "10":
                    System.out.println("Exiting...");
                    flag = true;
                    break;
                default:
                    System.out.println("Invalid option: " + choice);
            }
            if (flag) break;
        }
    }

    // Converts string input to array of integers
    private static Integer[] toArray(final String referenceString) {
        final Integer[] result = new Integer[referenceString.length()];
        for (int i = 0; i < referenceString.length(); i++) {
            result[i] = Character.digit(referenceString.charAt(i), 10);
        }
        return result;
    }
}
